
import pandas as pd
import numpy as np

def analyze_data_quality(df):
    if df is None or df.empty:
        return {
            "status": "INVALID",
            "rows": 0,
            "columns": 0,
            "missing_values": 0,
            "duplicate_records": 0,
            "numeric_anomalies": 0,
            "issues": ["No data available."]
        }

    issues = []

    missing = int(df.isna().sum().sum())

    duplicate_subset = [
        x for x in ["company", "year"]
        if x in df.columns
    ]

    if duplicate_subset:
        duplicates = int(
            df.duplicated(
                subset=duplicate_subset,
                keep=False
            ).sum()
        )
    else:
        duplicates = int(df.duplicated().sum())

    numeric_anomalies = 0

    for col in df.select_dtypes(include=np.number).columns:
        series = pd.to_numeric(df[col], errors="coerce")

        numeric_anomalies += int(
            np.isinf(series).sum()
        )

    if missing:
        issues.append(f"{missing} missing values detected.")

    if duplicates:
        issues.append(
            f"{duplicates} duplicate company/year records detected."
        )

    if numeric_anomalies:
        issues.append(
            f"{numeric_anomalies} infinite numeric values detected."
        )

    return {
        "status": "PASS" if not issues else "REVIEW",
        "rows": len(df),
        "columns": len(df.columns),
        "missing_values": missing,
        "duplicate_records": duplicates,
        "numeric_anomalies": numeric_anomalies,
        "issues": issues,
    }
